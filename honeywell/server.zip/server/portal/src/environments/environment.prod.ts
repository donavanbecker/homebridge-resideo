export const environment = {
  production: true,
  api: {
    base: '',
  },
  honeywell: {
    redirectUrl: 'https://homebridge-honeywell.iot.oz.nu/link-account',
    consumerKey: 'RTrCH5utygGV3vBymbbDdRI2yNh9aUj0',
  },
};
